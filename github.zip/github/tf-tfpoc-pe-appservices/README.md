# Template Repository
This repository will function as a base template to make new repositories from either manually or with automation.  
Teams, be sure to update this README!

# How to Use
You can create a new repository using this template by selecting it from the dropdown menu within the Create a Repository menu of the webUI:
![ExampleRepoCreation](https://user-images.githubusercontent.com/103216676/218492755-fba4c3bc-89f9-44a0-a6a8-10598b0415c5.png)

Please note - ProdDev team should have default write access to all repositories.

## CodeOwners file and PR
Be sure to update the CodeOwners file first after creating a new repo from this template.  The code owners file can create a seamless workflow that will issue PRs following the rules outlined in there.  Brief documentation and comments are included in the default CODEOWNERS file already present in this repository.  
![CodeOwners](https://user-images.githubusercontent.com/103216676/218494738-621edb0f-6465-49f8-a16d-a3eef8124d27.png)

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azapi"></a> [azapi](#requirement\_azapi) | >= 1.10.0, < 2.0 |
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >= 3.83.0 |
| <a name="requirement_null"></a> [null](#requirement\_null) | >= 3.0 |
| <a name="requirement_tls"></a> [tls](#requirement\_tls) | >= 3.1 |

### Providers

| Name | Version |
|------|---------|
| <a name="provider_tfe"></a> [tfe](#provider\_tfe) | n/a |

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_app_service_dev_01"></a> [app\_service\_dev\_01](#module\_app\_service\_dev\_01) | app.terraform.io/ddiworld/appservices/azurerm | 1.0.2 |

### Resources

| Name | Type |
|------|------|
| [tfe_outputs.vnetddi](https://registry.terraform.io/providers/hashicorp/tfe/latest/docs/data-sources/outputs) | data source |

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_app_service_plan_name"></a> [app\_service\_plan\_name](#input\_app\_service\_plan\_name) | Specifies the name of the App Service Plan component | `string` | `""` | no |
| <a name="input_create_app_service_plan"></a> [create\_app\_service\_plan](#input\_create\_app\_service\_plan) | Set to true if you want to create a new App Service Plan; false to use an existing one | `bool` | `true` | no |
| <a name="input_create_resource_group"></a> [create\_resource\_group](#input\_create\_resource\_group) | Whether to create resource group and use it for all networking resources | `bool` | `false` | no |
| <a name="input_enable_vnet_integration"></a> [enable\_vnet\_integration](#input\_enable\_vnet\_integration) | Manages an App Service Virtual Network Association | `bool` | `false` | no |
| <a name="input_location"></a> [location](#input\_location) | The location/region to keep all your network resources. To get the list of all locations with table format from azure cli, run 'az account list-locations -o table' | `string` | `""` | no |
| <a name="input_log_analytics_workspace_name"></a> [log\_analytics\_workspace\_name](#input\_log\_analytics\_workspace\_name) | The Name of the log\_analytics\_workspace for app insight | `string` | `""` | no |
| <a name="input_myapp_app_insights_name"></a> [myapp\_app\_insights\_name](#input\_myapp\_app\_insights\_name) | The Name of the application insights | `string` | `""` | no |
| <a name="input_myapp_app_service_name"></a> [myapp\_app\_service\_name](#input\_myapp\_app\_service\_name) | Specifies the name of the App Service Plan component | `string` | `""` | no |
| <a name="input_myapp_app_settings"></a> [myapp\_app\_settings](#input\_myapp\_app\_settings) | A key-value pair of App Settings. | `map(string)` | `{}` | no |
| <a name="input_myapp_enable_client_affinity"></a> [myapp\_enable\_client\_affinity](#input\_myapp\_enable\_client\_affinity) | Should the App Service send session affinity cookies, which route client requests in the same session to the same instance? | `bool` | `false` | no |
| <a name="input_myapp_site_config"></a> [myapp\_site\_config](#input\_myapp\_site\_config) | Site configuration for Application Service | `any` | `{}` | no |
| <a name="input_os_type"></a> [os\_type](#input\_os\_type) | Provide the OS type to be used | `string` | `"Windows"` | no |
| <a name="input_resource_group_name"></a> [resource\_group\_name](#input\_resource\_group\_name) | A container that holds related resources for an Azure solution | `string` | `""` | no |
| <a name="input_sku_name"></a> [sku\_name](#input\_sku\_name) | Provide the SKU to be used | `string` | `"Free"` | no |
| <a name="input_subnet_id"></a> [subnet\_id](#input\_subnet\_id) | The resource id of the subnet for vnet association | `any` | `null` | no |
| <a name="input_tags"></a> [tags](#input\_tags) | A map of tags to add to all resources | `map(string)` | `{}` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_app_service_id"></a> [app\_service\_id](#output\_app\_service\_id) | The resource ID of the App Service component |
| <a name="output_app_service_plan_id"></a> [app\_service\_plan\_id](#output\_app\_service\_plan\_id) | The resource ID of the App Service Plan component |
| <a name="output_app_service_virtual_network_swift_connection_id"></a> [app\_service\_virtual\_network\_swift\_connection\_id](#output\_app\_service\_virtual\_network\_swift\_connection\_id) | The ID of the App Service Virtual Network integration |
| <a name="output_application_insights_app_id"></a> [application\_insights\_app\_id](#output\_application\_insights\_app\_id) | The App ID associated with this Application Insights component |
| <a name="output_application_insights_connection_string"></a> [application\_insights\_connection\_string](#output\_application\_insights\_connection\_string) | The Connection String for this Application Insights component |
| <a name="output_application_insights_id"></a> [application\_insights\_id](#output\_application\_insights\_id) | The ID of the Application Insights component |
| <a name="output_application_insights_instrumentation_key"></a> [application\_insights\_instrumentation\_key](#output\_application\_insights\_instrumentation\_key) | The Instrumentation Key for this Application Insights component |
| <a name="output_default_site_hostname"></a> [default\_site\_hostname](#output\_default\_site\_hostname) | The Default Hostname associated with the App Service |
| <a name="output_identity"></a> [identity](#output\_identity) | An identity block, which contains the Managed Service Identity information for this App Service. |
| <a name="output_kind"></a> [kind](#output\_kind) | A string representing the Kind of Service Plan. |
| <a name="output_outbound_ip_address_list"></a> [outbound\_ip\_address\_list](#output\_outbound\_ip\_address\_list) | A list of outbound IP addresses |
| <a name="output_outbound_ip_addresses"></a> [outbound\_ip\_addresses](#output\_outbound\_ip\_addresses) | A comma separated list of outbound IP addresses |
| <a name="output_possible_outbound_ip_address_list"></a> [possible\_outbound\_ip\_address\_list](#output\_possible\_outbound\_ip\_address\_list) | A list of outbound IP addresses - not all of which are necessarily in use. Superset of outbound\_ip\_address\_list. |
| <a name="output_possible_outbound_ip_addresses"></a> [possible\_outbound\_ip\_addresses](#output\_possible\_outbound\_ip\_addresses) | A comma separated list of outbound IP addresses - not all of which are necessarily in use. Superset of `outbound_ip_addresses`. |
| <a name="output_sas_url_query_string"></a> [sas\_url\_query\_string](#output\_sas\_url\_query\_string) | n/a |
<!-- END_TF_DOCS -->