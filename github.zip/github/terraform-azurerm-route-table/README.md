# ddi-repo-template
This repository will function as a template for automation to make new repositories from
