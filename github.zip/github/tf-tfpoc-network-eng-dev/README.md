# Template Repository
This repository will function as a base template to make new repositories from either manually or with automation.  
Teams, be sure to update this README!

# How to Use
You can create a new repository using this template by selecting it from the dropdown menu within the Create a Repository menu of the webUI:
![ExampleRepoCreation](https://user-images.githubusercontent.com/103216676/218492755-fba4c3bc-89f9-44a0-a6a8-10598b0415c5.png)

Please note - ProdDev team should have default write access to all repositories.

## CodeOwners file and PR
Be sure to update the CodeOwners file first after creating a new repo from this template.  The code owners file can create a seamless workflow that will issue PRs following the rules outlined in there.  Brief documentation and comments are included in the default CODEOWNERS file already present in this repository.  
![CodeOwners](https://user-images.githubusercontent.com/103216676/218494738-621edb0f-6465-49f8-a16d-a3eef8124d27.png)

<!-- BEGIN_TF_DOCS -->
### Requirements

| Name | Version |
|------|---------|
| <a name="requirement_azurerm"></a> [azurerm](#requirement\_azurerm) | >=3.75.0 |
| <a name="requirement_tfe"></a> [tfe](#requirement\_tfe) | ~> 0.49.1 |

### Providers

No providers.

### Modules

| Name | Source | Version |
|------|--------|---------|
| <a name="module_cdn_frontdoor_afdendpoints"></a> [cdn\_frontdoor\_afdendpoints](#module\_cdn\_frontdoor\_afdendpoints) | app.terraform.io/ddiworld/cdn-frontdoor-afdendpoints/azurerm | 1.0.0 |
| <a name="module_cdn_frontdoor_domains"></a> [cdn\_frontdoor\_domains](#module\_cdn\_frontdoor\_domains) | app.terraform.io/ddiworld/cdn-frontdoor-domains/azurerm | 1.0.0 |
| <a name="module_cdn_frontdoor_origin"></a> [cdn\_frontdoor\_origin](#module\_cdn\_frontdoor\_origin) | app.terraform.io/ddiworld/cdn-frontdoor-origin/azurerm | 1.0.0 |
| <a name="module_cdn_frontdoor_origin_group"></a> [cdn\_frontdoor\_origin\_group](#module\_cdn\_frontdoor\_origin\_group) | app.terraform.io/ddiworld/cdn-frontdoor-origin-group/azurerm | 1.0.0 |
| <a name="module_cdn_frontdoor_profile"></a> [cdn\_frontdoor\_profile](#module\_cdn\_frontdoor\_profile) | app.terraform.io/ddiworld/cdn-frontdoor-profile/azurerm | 1.0.0 |
| <a name="module_firewall"></a> [firewall](#module\_firewall) | app.terraform.io/ddiworld/firewall/azurerm | 1.0.0 |
| <a name="module_network-interface-card"></a> [network-interface-card](#module\_network-interface-card) | app.terraform.io/ddiworld/network-interface-card/azurerm | 1.0.0 |
| <a name="module_network-security-group"></a> [network-security-group](#module\_network-security-group) | app.terraform.io/ddiworld/network-security-group/azurerm | 1.0.0 |
| <a name="module_private-dns-zone"></a> [private-dns-zone](#module\_private-dns-zone) | app.terraform.io/ddiworld/private-dns-zone/azurerm | 1.0.0 |
| <a name="module_public-ip"></a> [public-ip](#module\_public-ip) | app.terraform.io/ddiworld/public-ip/azurerm | 1.0.0 |
| <a name="module_resource_Group"></a> [resource\_Group](#module\_resource\_Group) | app.terraform.io/ddiworld/resource-group/azurerm | 1.0.0 |
| <a name="module_subnet"></a> [subnet](#module\_subnet) | app.terraform.io/ddiworld/subnet/azurerm | 1.0.0 |
| <a name="module_subnet_nsg_association"></a> [subnet\_nsg\_association](#module\_subnet\_nsg\_association) | app.terraform.io/ddiworld/subnet-nsg-association/azurerm | 1.0.2 |
| <a name="module_virtual_network"></a> [virtual\_network](#module\_virtual\_network) | app.terraform.io/ddiworld/virtual-network/azurerm | 1.0.0 |
| <a name="module_virtual_network_dns"></a> [virtual\_network\_dns](#module\_virtual\_network\_dns) | app.terraform.io/ddiworld/virtual-network-dns/azurerm | 1.0.0 |
| <a name="module_vnet_peering"></a> [vnet\_peering](#module\_vnet\_peering) | app.terraform.io/ddiworld/vnet-peering/azurerm | 1.0.0 |

### Resources

No resources.

### Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| <a name="input_azure_firewall_list"></a> [azure\_firewall\_list](#input\_azure\_firewall\_list) | list of azure firewall objects | `list(any)` | `[]` | no |
| <a name="input_cdn_endpoint_custom_domain_list"></a> [cdn\_endpoint\_custom\_domain\_list](#input\_cdn\_endpoint\_custom\_domain\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_cdn_frontdoor_endpoint_list"></a> [cdn\_frontdoor\_endpoint\_list](#input\_cdn\_frontdoor\_endpoint\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_cdn_frontdoor_origin_group_list"></a> [cdn\_frontdoor\_origin\_group\_list](#input\_cdn\_frontdoor\_origin\_group\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_cdn_frontdoor_origin_list"></a> [cdn\_frontdoor\_origin\_list](#input\_cdn\_frontdoor\_origin\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_cdn_frontdoor_profile_list"></a> [cdn\_frontdoor\_profile\_list](#input\_cdn\_frontdoor\_profile\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_network_interface_card_list"></a> [network\_interface\_card\_list](#input\_network\_interface\_card\_list) | list of network\_interface\_card\_list objects | `list(any)` | `[]` | no |
| <a name="input_network_security_group_list"></a> [network\_security\_group\_list](#input\_network\_security\_group\_list) | list of network\_security\_group\_list objects | `list(any)` | `[]` | no |
| <a name="input_private_dns_zone_list"></a> [private\_dns\_zone\_list](#input\_private\_dns\_zone\_list) | list of private dns zone group objects | `list(any)` | `[]` | no |
| <a name="input_public_ip_list"></a> [public\_ip\_list](#input\_public\_ip\_list) | list of public ip objects | `list(any)` | `[]` | no |
| <a name="input_resource_group_list"></a> [resource\_group\_list](#input\_resource\_group\_list) | list of resource\_group\_list objects | `list(any)` | `[]` | no |
| <a name="input_storage_account_list"></a> [storage\_account\_list](#input\_storage\_account\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_subnet_nsg_association_list"></a> [subnet\_nsg\_association\_list](#input\_subnet\_nsg\_association\_list) | n/a | `list(any)` | `[]` | no |
| <a name="input_virtual_network_dns_list"></a> [virtual\_network\_dns\_list](#input\_virtual\_network\_dns\_list) | list of virtual\_network\_dns\_list objects | `list(any)` | `[]` | no |
| <a name="input_virtual_network_list"></a> [virtual\_network\_list](#input\_virtual\_network\_list) | list of virtual\_network\_list objects | `list(any)` | `[]` | no |
| <a name="input_vnet_peering_list"></a> [vnet\_peering\_list](#input\_vnet\_peering\_list) | list of vnet for peering | `list(any)` | `[]` | no |
| <a name="input_vnet_subnet_list"></a> [vnet\_subnet\_list](#input\_vnet\_subnet\_list) | list of vnet\_subnet\_list objects | `list(any)` | `[]` | no |

### Outputs

| Name | Description |
|------|-------------|
| <a name="output_network_interface_card_output"></a> [network\_interface\_card\_output](#output\_network\_interface\_card\_output) | n/a |
| <a name="output_private_dns_zone_output"></a> [private\_dns\_zone\_output](#output\_private\_dns\_zone\_output) | n/a |
| <a name="output_public_ip_output"></a> [public\_ip\_output](#output\_public\_ip\_output) | n/a |
| <a name="output_resource_group_output"></a> [resource\_group\_output](#output\_resource\_group\_output) | n/a |
| <a name="output_virtual_network_dns_output"></a> [virtual\_network\_dns\_output](#output\_virtual\_network\_dns\_output) | n/a |
| <a name="output_virtual_network_output"></a> [virtual\_network\_output](#output\_virtual\_network\_output) | n/a |
| <a name="output_vnet_peering"></a> [vnet\_peering](#output\_vnet\_peering) | output "route\_table\_output" { value = module.route\_table.route\_table\_output } |
| <a name="output_vnet_subnet_output"></a> [vnet\_subnet\_output](#output\_vnet\_subnet\_output) | n/a |
<!-- END_TF_DOCS -->