param(
    [Parameter(Mandatory = $True, Position = 0, ValueFromPipeline = $false)]
    [System.String]
    $environment
)

$env = switch ($environment.ToLower()) {
    "development" { "dev" }
    "qa" { "qa" }
    "sandbox" { "sdx" }
    "prod" { "prod" }
}

$fw = New-Object PSObject -Property @{
    storage_rg_name        = 'rg-' + $env + '-da-data-eastus-001' #resource group name
    storage_account_name   = 'st' + $env + 'daeastus001'#storage account name
    firewall_defaultaction = 'Allow'
    kv_rg_name             = 'rg-' + $env + '-da-shared-eastus-001'
    kv_name                = 'kv-' + $env + '-da-shared-eastus'
}

Write-Host 'Subscription details: '
#az account set --subscription $subscription_id
az account show

try {

    Write-Host 'Checking whether storage account exixts...'
    $stExists = az storage account show --resource-group $fw.storage_rg_name --name $fw.storage_account_name --query name
    Write-Host 'Checking whether Key Vault exists...'
    $kvExists = az keyvault show --resource-group $fw.kv_rg_name --name $fw.kv_name --query name
    if (!$stExists) { 
       
    }
    elseif (!$kvExists) { 
       
    }
}
catch {
    Write-Output 'Exception raised while checking whether storage account/keyvault exists or not'
    Write-Output $_.Exception.Message
}

try {
    if ($stExists) {
        Write-Host 'Storage account exists! Proceeding with removing network restrictions...'
        az storage account update --resource-group $fw.storage_rg_name --name $fw.storage_account_name --default-action $fw.firewall_defaultaction
    }
    else {
        Write-Host "Storage account $fw.storage_account_name  does not exist yet!. Exiting."
        exit 1
    }
    if ($kvExists) {
        #$nwrules = az keyvault network-rule list --name $fw.kv_name
        Write-Host 'Keyvault exists! Proceeding with setting network ACLs as Allow...'
        az keyvault update --name $fw.kv_name --default-action $fw.firewall_defaultaction
    }
    else {
        Write-Host "Keyvault $fw.kv_name does not exist yet!. Exiting. "
        exit 1
    }
    
}
catch {
    Write-Output 'Exception raised while removing network restrictions'
    Write-Output $_.Exception.Message
}