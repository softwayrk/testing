[CmdletBinding()]
param (
    [Parameter()]
    [string]
    $storage_account_name,
    [list(string)]
    $storage_subnets_ids,
    [string]
    $adb_access_connector_id,
    [string]
    $tenant_id
)

$vnet_rules = (az storage account network-rule list --account-name $storage_account_name) | ConvertFrom-Json
$allowedSubnets = @($vnet_rules.virtualNetworkRules.virtualNetworkResourceId)
$allowedResourceIns = @($vnet_rules.resourceAccessRules.resourceId)
Write-Host "CURRENT TOTAL - Allowed Subnets="$allowedSubnets.Count "Allowed ResourceInstances="$allowedResourceIns.Count         

foreach ($subnetId in $storage_subnets_ids) {
    if ($allowedSubnets -notcontains $subnetId) {
        "Adding subnet to allowed list: $subnetId"
        az storage account update --name $storage_account_name --add networkRuleSet.virtualNetworkRules id=$subnetId
    }
}       
if ($adb_access_connector_id -notin $allowedResourceIns) {
    "Adding access connector to allowed list.."
    az storage account update --name $storage_account_name --add networkRuleSet.resourceAccessRules resourceId=$adb_access_connector_id tenantId=$tenant_id
}
az storage account update --name $storage_account_name --default-action Deny