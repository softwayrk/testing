#This folder is intended for placing static files (including script files that aren't executed by the terraform configuration we define)

#Static files