# Template Repository
This repository is used for placing all the shared templates and scripts that can be called by other repos.

# How to Use
Please make use of the 'reusable workflows' concept for calling a workflow stored in this repo. 
Or download this repo in Github action to make use of the scripts and other files stored in this repo.

## CodeOwners file and PR
Be sure to update the CodeOwners file for setting different PR reviewers for different folders.  
![CodeOwners](https://user-images.githubusercontent.com/103216676/218494738-621edb0f-6465-49f8-a16d-a3eef8124d27.png)
